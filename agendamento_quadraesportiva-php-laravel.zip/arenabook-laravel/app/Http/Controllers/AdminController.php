<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    /**
     * GET /api/admin/usuarios
     * Lista todos os usuários.
     */
    public function usuarios(): JsonResponse
    {
        $usuarios = Usuario::orderByDesc('created_at')->get();

        return response()->json([
            'ok'   => true,
            'data' => $usuarios->map->toApiArray()->values(),
        ]);
    }

    /**
     * POST /api/admin/usuarios/{id}/toggle
     * Ativa ou desativa um usuário.
     */
    public function toggleUsuario(int $id): JsonResponse
    {
        $usuario = Usuario::findOrFail($id);
        $usuario->update(['ativo' => ! $usuario->ativo]);

        return response()->json([
            'ok'   => true,
            'data' => ['ok' => true, 'ativo' => $usuario->fresh()->ativo],
        ]);
    }
}
