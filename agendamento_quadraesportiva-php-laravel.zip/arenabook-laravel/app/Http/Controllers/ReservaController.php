<?php

namespace App\Http\Controllers;

use App\Http\Requests\ReservaRequest;
use App\Models\Quadra;
use App\Models\Reserva;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReservaController extends Controller
{
    /**
     * POST /api/reservas
     * Cria uma nova reserva para o usuário autenticado.
     */
    public function store(ReservaRequest $request): JsonResponse
    {
        $data = $request->validated();

        // Não permite datas no passado
        if ($data['data'] < now()->format('Y-m-d')) {
            return response()->json([
                'ok'   => false,
                'erro' => 'Não é possível reservar datas no passado.',
            ], 422);
        }

        // Verifica conflito de horário
        if (Reserva::temConflito(
            $data['quadra_id'],
            $data['data'],
            $data['hora_inicio'],
            $data['hora_fim']
        )) {
            return response()->json([
                'ok'   => false,
                'erro' => 'Horário já reservado para essa quadra.',
            ], 409);
        }

        // Calcula valor total
        $quadra = Quadra::findOrFail($data['quadra_id']);
        $horas  = (int) substr($data['hora_fim'], 0, 2)
                - (int) substr($data['hora_inicio'], 0, 2);
        $valor  = round($quadra->preco_hora * $horas, 2);

        $reserva = Reserva::create([
            'usuario_id'  => $request->user()->id,
            'quadra_id'   => $data['quadra_id'],
            'data'        => $data['data'],
            'hora_inicio' => $data['hora_inicio'],
            'hora_fim'    => $data['hora_fim'],
            'valor_total' => $valor,
            'observacao'  => $data['observacao'] ?? '',
        ]);

        // Eager-load para montar resposta completa
        $reserva->load(['usuario', 'quadra']);

        return response()->json([
            'ok'   => true,
            'data' => $reserva->toApiArray(),
        ], 201);
    }

    /**
     * GET /api/reservas
     * Histórico de reservas do usuário autenticado.
     */
    public function minhas(Request $request): JsonResponse
    {
        $reservas = Reserva::with(['usuario', 'quadra'])
            ->where('usuario_id', $request->user()->id)
            ->orderByDesc('data')
            ->orderByDesc('hora_inicio')
            ->get();

        return response()->json([
            'ok'   => true,
            'data' => $reservas->map->toApiArray()->values(),
        ]);
    }

    /**
     * DELETE /api/reservas/{id}
     * Cancela a própria reserva (ou qualquer uma, se admin).
     */
    public function cancelar(Request $request, int $id): JsonResponse
    {
        $usuario = $request->user();

        $query = Reserva::where('id', $id);

        // Admins podem cancelar qualquer reserva; usuários só as suas
        if (! $usuario->is_admin) {
            $query->where('usuario_id', $usuario->id);
        }

        $reserva = $query->first();

        if (! $reserva) {
            return response()->json([
                'ok'   => false,
                'erro' => 'Reserva não encontrada ou sem permissão.',
            ], 403);
        }

        $reserva->update(['status' => 'cancelada']);

        return response()->json([
            'ok'   => true,
            'data' => ['mensagem' => 'Reserva cancelada.'],
        ]);
    }

    // ─── Admin ────────────────────────────────────────────────

    /**
     * GET /api/admin/reservas
     * Todas as reservas (admin).
     */
    public function adminIndex(): JsonResponse
    {
        $reservas = Reserva::with(['usuario', 'quadra'])
            ->orderByDesc('data')
            ->orderByDesc('hora_inicio')
            ->get();

        return response()->json([
            'ok'   => true,
            'data' => $reservas->map->toApiArray()->values(),
        ]);
    }

    /**
     * GET /api/admin/relatorio
     * Estatísticas gerais (admin).
     */
    public function relatorio(): JsonResponse
    {
        $total      = Reserva::count();
        $ativas     = Reserva::confirmadas()->count();
        $canceladas = Reserva::canceladas()->count();
        $receita    = Reserva::confirmadas()->sum('valor_total');
        $usuarios   = \App\Models\Usuario::clientes()->count();
        $quadras    = \App\Models\Quadra::ativas()->count();

        // Quadra mais reservada
        $top = Reserva::confirmadas()
            ->selectRaw('quadra_id, COUNT(*) as total')
            ->groupBy('quadra_id')
            ->orderByDesc('total')
            ->with('quadra:id,nome')
            ->first();

        return response()->json([
            'ok'   => true,
            'data' => [
                'total_reservas'        => $total,
                'reservas_ativas'       => $ativas,
                'reservas_canceladas'   => $canceladas,
                'receita_total'         => round((float) $receita, 2),
                'total_usuarios'        => $usuarios,
                'total_quadras'         => $quadras,
                'quadra_mais_reservada' => $top?->quadra?->nome ?? 'N/A',
            ],
        ]);
    }
}
