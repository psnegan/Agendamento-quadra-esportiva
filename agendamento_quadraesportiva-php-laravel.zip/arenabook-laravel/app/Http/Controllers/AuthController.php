<?php

namespace App\Http\Controllers;

use App\Http\Requests\CadastroRequest;
use App\Http\Requests\LoginRequest;
use App\Models\Usuario;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    /**
     * POST /api/cadastro
     * Cria uma nova conta de usuário.
     */
    public function cadastro(CadastroRequest $request): JsonResponse
    {
        $usuario = Usuario::create([
            'nome'       => $request->nome,
            'email'      => $request->email,
            'senha_hash' => Hash::make($request->senha),
            'telefone'   => $request->telefone ?? '',
        ]);

        $token = $usuario->createToken('api')->plainTextToken;

        return response()->json([
            'ok'    => true,
            'data'  => $usuario->toApiArray(),
            'token' => $token,
        ], 201);
    }

    /**
     * POST /api/login
     * Autentica e retorna um token Sanctum.
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $usuario = Usuario::where('email', $request->email)
            ->where('ativo', true)
            ->first();

        if (! $usuario || ! Hash::check($request->senha, $usuario->senha_hash)) {
            return response()->json([
                'ok'   => false,
                'erro' => 'E-mail ou senha inválidos.',
            ], 401);
        }

        // Revoga tokens anteriores (sessão única por dispositivo — remova se quiser múltiplos)
        $usuario->tokens()->delete();

        $token = $usuario->createToken('api')->plainTextToken;

        return response()->json([
            'ok'    => true,
            'data'  => $usuario->toApiArray(),
            'token' => $token,
        ]);
    }

    /**
     * POST /api/logout
     * Revoga o token atual.
     */
    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'ok'   => true,
            'data' => ['mensagem' => 'Logout realizado.'],
        ]);
    }

    /**
     * GET /api/me
     * Retorna o usuário autenticado.
     */
    public function me(Request $request): JsonResponse
    {
        return response()->json([
            'ok'   => true,
            'data' => $request->user()->toApiArray(),
        ]);
    }
}
