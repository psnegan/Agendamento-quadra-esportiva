<?php

namespace App\Http\Controllers;

use App\Http\Requests\QuadraRequest;
use App\Models\Quadra;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class QuadraController extends Controller
{
    /**
     * GET /api/quadras
     * Lista quadras ativas (público).
     */
    public function index(): JsonResponse
    {
        $quadras = Quadra::ativas()->orderBy('nome')->get();

        return response()->json([
            'ok'   => true,
            'data' => $quadras->map->toApiArray()->values(),
        ]);
    }

    /**
     * GET /api/horarios?quadra_id={id}&data={YYYY-MM-DD}
     * Retorna horários disponíveis numa data (público).
     */
    public function horarios(Request $request): JsonResponse
    {
        $request->validate([
            'quadra_id' => 'required|integer|exists:quadras,id',
            'data'      => 'required|date_format:Y-m-d',
        ]);

        $quadra = Quadra::findOrFail($request->quadra_id);

        return response()->json([
            'ok'   => true,
            'data' => $quadra->horariosDisponiveis($request->data),
        ]);
    }

    // ─── Admin ────────────────────────────────────────────────

    /**
     * GET /api/admin/quadras
     * Lista todas as quadras (admin).
     */
    public function adminIndex(): JsonResponse
    {
        $quadras = Quadra::orderBy('nome')->get();

        return response()->json([
            'ok'   => true,
            'data' => $quadras->map->toApiArray()->values(),
        ]);
    }

    /**
     * POST /api/admin/quadras
     * Cria uma nova quadra (admin).
     */
    public function store(QuadraRequest $request): JsonResponse
    {
        $quadra = Quadra::create($request->validated());

        return response()->json([
            'ok'   => true,
            'data' => $quadra->toApiArray(),
        ], 201);
    }

    /**
     * PUT /api/admin/quadras/{id}
     * Atualiza uma quadra (admin).
     */
    public function update(QuadraRequest $request, int $id): JsonResponse
    {
        $quadra = Quadra::findOrFail($id);
        $quadra->update($request->validated());

        return response()->json([
            'ok'   => true,
            'data' => $quadra->fresh()->toApiArray(),
        ]);
    }

    /**
     * DELETE /api/admin/quadras/{id}
     * Soft-delete: desativa a quadra (admin).
     */
    public function destroy(int $id): JsonResponse
    {
        $quadra = Quadra::findOrFail($id);
        $quadra->update(['ativa' => false]);

        return response()->json([
            'ok'   => true,
            'data' => ['removida' => true],
        ]);
    }
}
