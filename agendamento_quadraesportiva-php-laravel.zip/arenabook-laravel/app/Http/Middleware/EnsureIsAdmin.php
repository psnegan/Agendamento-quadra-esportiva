<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Middleware que garante que apenas administradores acessem as rotas protegidas.
 * Deve ser usado em conjunto com 'auth:sanctum'.
 *
 * Registro no Kernel (app/Http/Kernel.php) — adicione no array $routeMiddleware:
 *   'admin' => \App\Http\Middleware\EnsureIsAdmin::class,
 *
 * Ou no Laravel 11+, em bootstrap/app.php:
 *   ->withMiddleware(function (Middleware $middleware) {
 *       $middleware->alias(['admin' => EnsureIsAdmin::class]);
 *   })
 */
class EnsureIsAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! $request->user() || ! $request->user()->is_admin) {
            return response()->json([
                'ok'   => false,
                'erro' => 'Acesso restrito a administradores.',
            ], 403);
        }

        return $next($request);
    }
}
