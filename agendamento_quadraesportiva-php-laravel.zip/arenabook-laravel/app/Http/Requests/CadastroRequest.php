<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CadastroRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'nome'     => 'required|string|max:255',
            'email'    => 'required|email|unique:usuarios,email',
            'senha'    => 'required|string|min:6',
            'telefone' => 'nullable|string|max:20',
        ];
    }

    public function messages(): array
    {
        return [
            'nome.required'   => 'O nome é obrigatório.',
            'email.required'  => 'O e-mail é obrigatório.',
            'email.email'     => 'Informe um e-mail válido.',
            'email.unique'    => 'E-mail já cadastrado.',
            'senha.required'  => 'A senha é obrigatória.',
            'senha.min'       => 'A senha deve ter ao menos 6 caracteres.',
        ];
    }
}
