<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ReservaRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // usuário autenticado via middleware 'auth:sanctum'
    }

    public function rules(): array
    {
        return [
            'quadra_id'   => 'required|integer|exists:quadras,id',
            'data'        => 'required|date_format:Y-m-d',
            'hora_inicio' => 'required|date_format:H:i',
            'hora_fim'    => 'required|date_format:H:i|after:hora_inicio',
            'observacao'  => 'nullable|string|max:500',
        ];
    }

    public function messages(): array
    {
        return [
            'quadra_id.required'   => 'Informe a quadra.',
            'quadra_id.exists'     => 'Quadra não encontrada.',
            'data.required'        => 'Informe a data.',
            'data.date_format'     => 'Data inválida. Use o formato YYYY-MM-DD.',
            'hora_inicio.required' => 'Informe o horário de início.',
            'hora_fim.required'    => 'Informe o horário de fim.',
            'hora_fim.after'       => 'O horário de fim deve ser depois do início.',
        ];
    }
}
