<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class QuadraRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // autorização via middleware 'admin' na rota
    }

    public function rules(): array
    {
        return [
            'nome'       => 'required|string|max:255',
            'tipo'       => 'required|string|max:100',
            'descricao'  => 'nullable|string',
            'preco_hora' => 'required|numeric|min:0',
            'capacidade' => 'nullable|integer|min:1',
            'emoji'      => 'nullable|string|max:10',
            'ativa'      => 'nullable|boolean',
        ];
    }

    public function messages(): array
    {
        return [
            'nome.required'       => 'O nome da quadra é obrigatório.',
            'tipo.required'       => 'O tipo é obrigatório.',
            'preco_hora.required' => 'O preço por hora é obrigatório.',
            'preco_hora.numeric'  => 'O preço deve ser um número.',
        ];
    }
}
