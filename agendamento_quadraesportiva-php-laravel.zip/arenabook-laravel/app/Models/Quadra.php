<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Quadra extends Model
{
    use HasFactory;

    protected $table = 'quadras';

    protected $fillable = [
        'nome',
        'tipo',
        'descricao',
        'preco_hora',
        'capacidade',
        'emoji',
        'ativa',
    ];

    protected $casts = [
        'preco_hora' => 'float',
        'capacidade' => 'integer',
        'ativa'      => 'boolean',
    ];

    // ─── Relacionamentos ──────────────────────────────────────

    /**
     * Reservas desta quadra.
     */
    public function reservas()
    {
        return $this->hasMany(Reserva::class, 'quadra_id');
    }

    // ─── Scopes ───────────────────────────────────────────────

    /**
     * Somente quadras ativas.
     */
    public function scopeAtivas($query)
    {
        return $query->where('ativa', true);
    }

    // ─── Helpers ──────────────────────────────────────────────

    /**
     * Retorna os horários (07h–21h) com flag de disponibilidade
     * para uma data específica.
     *
     * @param  string $data  Formato: YYYY-MM-DD
     * @return array
     */
    public function horariosDisponiveis(string $data): array
    {
        // Busca reservas confirmadas nesta quadra/data
        $reservas = $this->reservas()
            ->where('data', $data)
            ->where('status', 'confirmada')
            ->get(['hora_inicio', 'hora_fim']);

        // Monta conjunto de horas ocupadas
        $ocupados = [];
        foreach ($reservas as $reserva) {
            $h = (int) substr($reserva->hora_inicio, 0, 2);
            while ($h < (int) substr($reserva->hora_fim, 0, 2)) {
                $ocupados[] = sprintf('%02d:00', $h);
                $h++;
            }
        }

        // Gera slots de 07h a 21h
        $horarios = [];
        for ($h = 7; $h < 22; $h++) {
            $slot       = sprintf('%02d:00', $h);
            $horarios[] = [
                'horario'    => $slot,
                'disponivel' => ! in_array($slot, $ocupados),
            ];
        }

        return $horarios;
    }

    /**
     * Array para resposta da API.
     */
    public function toApiArray(): array
    {
        return [
            'id'         => $this->id,
            'nome'       => $this->nome,
            'tipo'       => $this->tipo,
            'descricao'  => $this->descricao,
            'preco_hora' => $this->preco_hora,
            'capacidade' => $this->capacidade,
            'emoji'      => $this->emoji,
            'ativa'      => $this->ativa,
        ];
    }
}
