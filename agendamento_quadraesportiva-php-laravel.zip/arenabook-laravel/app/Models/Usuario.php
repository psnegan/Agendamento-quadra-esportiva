<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Usuario extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * Nome da tabela no banco.
     */
    protected $table = 'usuarios';

    /**
     * Campos que podem ser preenchidos em massa.
     */
    protected $fillable = [
        'nome',
        'email',
        'senha_hash',
        'telefone',
        'is_admin',
        'ativo',
    ];

    /**
     * Campos ocultos na serialização JSON.
     */
    protected $hidden = [
        'senha_hash',
    ];

    /**
     * Casts de tipos.
     */
    protected $casts = [
        'is_admin' => 'boolean',
        'ativo'    => 'boolean',
    ];

    /**
     * O campo de senha do Laravel aponta para senha_hash.
     * Necessário para compatibilidade com Auth e Sanctum.
     */
    public function getAuthPassword(): string
    {
        return $this->senha_hash;
    }

    // ─── Relacionamentos ──────────────────────────────────────

    /**
     * Reservas deste usuário.
     */
    public function reservas()
    {
        return $this->hasMany(Reserva::class, 'usuario_id');
    }

    // ─── Scopes ───────────────────────────────────────────────

    /**
     * Somente usuários ativos.
     */
    public function scopeAtivos($query)
    {
        return $query->where('ativo', true);
    }

    /**
     * Somente usuários comuns (não admin).
     */
    public function scopeClientes($query)
    {
        return $query->where('is_admin', false);
    }

    // ─── Helpers ──────────────────────────────────────────────

    /**
     * Retorna array formatado para resposta da API
     * (mantém estrutura igual ao projeto original).
     */
    public function toApiArray(): array
    {
        return [
            'id'        => $this->id,
            'nome'      => $this->nome,
            'email'     => $this->email,
            'telefone'  => $this->telefone,
            'is_admin'  => $this->is_admin,
            'ativo'     => $this->ativo,
            'criado_em' => $this->created_at?->toDateTimeString(),
        ];
    }
}
