<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reserva extends Model
{
    use HasFactory;

    protected $table = 'reservas';

    protected $fillable = [
        'usuario_id',
        'quadra_id',
        'data',
        'hora_inicio',
        'hora_fim',
        'status',
        'valor_total',
        'observacao',
    ];

    protected $casts = [
        'data'        => 'date:Y-m-d',
        'valor_total' => 'float',
    ];

    // ─── Relacionamentos ──────────────────────────────────────

    public function usuario()
    {
        return $this->belongsTo(Usuario::class, 'usuario_id');
    }

    public function quadra()
    {
        return $this->belongsTo(Quadra::class, 'quadra_id');
    }

    // ─── Scopes ───────────────────────────────────────────────

    public function scopeConfirmadas($query)
    {
        return $query->where('status', 'confirmada');
    }

    public function scopeCanceladas($query)
    {
        return $query->where('status', 'cancelada');
    }

    // ─── Helpers ──────────────────────────────────────────────

    /**
     * Verifica conflito de horário para uma quadra/data.
     * Retorna true se o slot já está ocupado.
     */
    public static function temConflito(
        int    $quadraId,
        string $data,
        string $horaInicio,
        string $horaFim,
        ?int   $excluirId = null
    ): bool {
        $query = static::where('quadra_id', $quadraId)
            ->where('data', $data)
            ->where('status', 'confirmada')
            ->where('hora_inicio', '<', $horaFim)
            ->where('hora_fim', '>', $horaInicio);

        if ($excluirId) {
            $query->where('id', '!=', $excluirId);
        }

        return $query->exists();
    }

    /**
     * Calcula o valor total baseado no preço/hora da quadra.
     */
    public function calcularValor(): float
    {
        $horas = (int) substr($this->hora_fim, 0, 2)
               - (int) substr($this->hora_inicio, 0, 2);

        return round($this->quadra->preco_hora * $horas, 2);
    }

    /**
     * Array para resposta da API (com nomes via eager loading).
     */
    public function toApiArray(): array
    {
        return [
            'id'           => $this->id,
            'usuario_id'   => $this->usuario_id,
            'usuario_nome' => $this->usuario?->nome ?? '',
            'quadra_id'    => $this->quadra_id,
            'quadra_nome'  => $this->quadra?->nome ?? '',
            'quadra_emoji' => $this->quadra?->emoji ?? '',
            'data'         => $this->data instanceof \Carbon\Carbon
                                ? $this->data->format('Y-m-d')
                                : $this->data,
            'hora_inicio'  => $this->hora_inicio,
            'hora_fim'     => $this->hora_fim,
            'status'       => $this->status,
            'valor_total'  => $this->valor_total,
            'observacao'   => $this->observacao,
            'criado_em'    => $this->created_at?->toDateTimeString(),
        ];
    }
}
