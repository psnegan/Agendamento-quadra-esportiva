# 🏟️ ArenaBook — Laravel

Sistema de agendamento de quadra esportiva migrado do PHP puro para **Laravel 11** com autenticação via **Sanctum** (token Bearer).

---

## 📁 Estrutura dos arquivos gerados

```
arenabook-laravel/
│
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AuthController.php       ← cadastro, login, logout, me
│   │   │   ├── QuadraController.php     ← CRUD de quadras + horários
│   │   │   ├── ReservaController.php    ← reservar, cancelar, relatório
│   │   │   └── AdminController.php      ← gestão de usuários (admin)
│   │   ├── Middleware/
│   │   │   └── EnsureIsAdmin.php        ← bloqueia rotas de admin
│   │   └── Requests/
│   │       ├── CadastroRequest.php
│   │       ├── LoginRequest.php
│   │       ├── QuadraRequest.php
│   │       └── ReservaRequest.php
│   └── Models/
│       ├── Usuario.php                  ← Authenticatable + Sanctum
│       ├── Quadra.php
│       └── Reserva.php
│
├── database/
│   ├── migrations/
│   │   ├── ..._create_usuarios_table.php
│   │   ├── ..._create_quadras_table.php
│   │   └── ..._create_reservas_table.php
│   └── seeders/
│       ├── DatabaseSeeder.php
│       ├── UsuarioSeeder.php            ← admin@quadra.com / admin123
│       └── QuadraSeeder.php             ← 4 quadras de exemplo
│
├── routes/
│   └── api.php                          ← todas as rotas REST
│
└── .env.example                         ← configuração de ambiente
```

---

## 🚀 Instalação (passo a passo)

### 1. Criar o projeto Laravel

```bash
composer create-project laravel/laravel arenabook
cd arenabook
```

### 2. Instalar Sanctum

```bash
composer require laravel/sanctum
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
```

### 3. Copiar os arquivos

Substitua / adicione os arquivos desta pasta no projeto Laravel criado:

```bash
# Copie cada pasta para o projeto
cp -r app/Http/Controllers/* arenabook/app/Http/Controllers/
cp -r app/Http/Middleware/EnsureIsAdmin.php arenabook/app/Http/Middleware/
cp -r app/Http/Requests/* arenabook/app/Http/Requests/
cp -r app/Models/* arenabook/app/Models/
cp -r database/migrations/* arenabook/database/migrations/
cp -r database/seeders/* arenabook/database/seeders/
cp routes/api.php arenabook/routes/api.php
```

### 4. Configurar o ambiente

```bash
cp .env.example arenabook/.env
cd arenabook
php artisan key:generate
```

**SQLite (padrão — sem instalação):**
```bash
touch database/database.sqlite
# O .env já vem configurado para SQLite
```

**MySQL (opcional):**
```
# No .env, altere:
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=quadra_esportiva
DB_USERNAME=root
DB_PASSWORD=sua_senha
```

### 5. Registrar o middleware Admin

**Laravel 10 — em `app/Http/Kernel.php`**, adicione em `$routeMiddleware`:
```php
'admin' => \App\Http\Middleware\EnsureIsAdmin::class,
```

**Laravel 11 — em `bootstrap/app.php`**:
```php
->withMiddleware(function (Middleware $middleware) {
    $middleware->alias([
        'admin' => \App\Http\Middleware\EnsureIsAdmin::class,
    ]);
})
```

### 6. Configurar o Model `Usuario` como autenticável

Em `config/auth.php`, altere o provider de users:
```php
'providers' => [
    'users' => [
        'driver' => 'eloquent',
        'model'  => App\Models\Usuario::class,  // ← troque de User para Usuario
    ],
],
```

### 7. Migrations e Seed

```bash
php artisan migrate
php artisan db:seed
```

### 8. Rodar o servidor

```bash
php artisan serve
# API disponível em: http://localhost:8000/api
```

---

## 📡 Endpoints da API

### Autenticação (público)

| Método | Endpoint        | Body                          | Descrição     |
|--------|-----------------|-------------------------------|---------------|
| POST   | `/api/cadastro` | nome, email, senha, telefone  | Criar conta   |
| POST   | `/api/login`    | email, senha                  | Login → token |

### Autenticado (`Authorization: Bearer {token}`)

| Método | Endpoint              | Body / Params                           | Descrição            |
|--------|-----------------------|-----------------------------------------|----------------------|
| POST   | `/api/logout`         | —                                       | Encerrar sessão      |
| GET    | `/api/me`             | —                                       | Usuário atual        |
| GET    | `/api/quadras`        | —                                       | Quadras ativas       |
| GET    | `/api/horarios`       | ?quadra_id=1&data=2025-08-01            | Horários disponíveis |
| POST   | `/api/reservas`       | quadra_id, data, hora_inicio, hora_fim  | Criar reserva        |
| GET    | `/api/reservas`       | —                                       | Minhas reservas      |
| DELETE | `/api/reservas/{id}`  | —                                       | Cancelar reserva     |

### Admin (`is_admin = true` obrigatório)

| Método | Endpoint                            | Descrição                 |
|--------|-------------------------------------|---------------------------|
| GET    | `/api/admin/quadras`                | Todas as quadras          |
| POST   | `/api/admin/quadras`                | Criar quadra              |
| PUT    | `/api/admin/quadras/{id}`           | Editar quadra             |
| DELETE | `/api/admin/quadras/{id}`           | Desativar quadra          |
| GET    | `/api/admin/reservas`               | Todas as reservas         |
| GET    | `/api/admin/relatorio`              | Estatísticas gerais       |
| GET    | `/api/admin/usuarios`               | Todos os usuários         |
| POST   | `/api/admin/usuarios/{id}/toggle`   | Ativar/desativar usuário  |

---

## 🔑 Credenciais padrão (seed)

| Campo  | Admin              | Usuário teste        |
|--------|--------------------|----------------------|
| Email  | admin@quadra.com   | usuario@quadra.com   |
| Senha  | admin123           | user123              |

---

## 🗺️ Equivalência com o projeto original

| PHP puro                    | Laravel                                      |
|-----------------------------|----------------------------------------------|
| `config/database.php`       | `config/database.php` + `.env`               |
| `Database::migrate()`       | `php artisan migrate`                        |
| `classes/Usuario.php`       | `app/Models/Usuario.php`                     |
| `classes/Quadra.php`        | `app/Models/Quadra.php`                      |
| `classes/Reserva.php`       | `app/Models/Reserva.php`                     |
| `api/index.php` (switch)    | `routes/api.php` + Controllers               |
| `$_SESSION['usuario_id']`   | Sanctum Bearer Token                         |
| `isAdmin()`                 | Middleware `EnsureIsAdmin`                   |
| Seed inline no `migrate()`  | `database/seeders/`                          |
| Validação manual            | `app/Http/Requests/` (FormRequests)          |

---

## 📦 Dependências necessárias

```bash
composer require laravel/sanctum
```

> Laravel 11 já inclui Sanctum por padrão. Para Laravel 10, instale manualmente.
