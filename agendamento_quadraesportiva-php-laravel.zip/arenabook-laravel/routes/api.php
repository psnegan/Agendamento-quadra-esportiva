<?php

/**
 * ============================================================
 *  routes/api.php  —  ArenaBook API Routes
 * ============================================================
 *
 *  Todas as rotas têm prefixo /api (configurado no RouteServiceProvider).
 *
 *  Autenticação via Laravel Sanctum (Bearer Token).
 *  Header:  Authorization: Bearer {token}
 *
 *  Middleware 'admin' requer is_admin = true no usuário logado.
 * ============================================================
 */

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\QuadraController;
use App\Http\Controllers\ReservaController;
use Illuminate\Support\Facades\Route;

// ─── Autenticação (público) ───────────────────────────────────
Route::post('/cadastro', [AuthController::class, 'cadastro']);
Route::post('/login',    [AuthController::class, 'login']);

// ─── Quadras (público) ────────────────────────────────────────
Route::get('/quadras',  [QuadraController::class, 'index']);
Route::get('/horarios', [QuadraController::class, 'horarios']);

// ─── Rotas autenticadas (Sanctum) ────────────────────────────
Route::middleware('auth:sanctum')->group(function () {

    // Auth
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me',      [AuthController::class, 'me']);

    // Reservas do usuário logado
    Route::get('/reservas',          [ReservaController::class, 'minhas']);
    Route::post('/reservas',         [ReservaController::class, 'store']);
    Route::delete('/reservas/{id}',  [ReservaController::class, 'cancelar']);

    // ─── Admin ────────────────────────────────────────────────
    Route::middleware('admin')->prefix('admin')->group(function () {

        // Quadras
        Route::get('/quadras',         [QuadraController::class, 'adminIndex']);
        Route::post('/quadras',        [QuadraController::class, 'store']);
        Route::put('/quadras/{id}',    [QuadraController::class, 'update']);
        Route::delete('/quadras/{id}', [QuadraController::class, 'destroy']);

        // Reservas
        Route::get('/reservas',        [ReservaController::class, 'adminIndex']);
        Route::get('/relatorio',       [ReservaController::class, 'relatorio']);

        // Usuários
        Route::get('/usuarios',                        [AdminController::class, 'usuarios']);
        Route::post('/usuarios/{id}/toggle',           [AdminController::class, 'toggleUsuario']);
    });
});
