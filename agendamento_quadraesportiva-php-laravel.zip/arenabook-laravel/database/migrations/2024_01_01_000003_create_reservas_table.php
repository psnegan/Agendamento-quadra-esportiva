<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('reservas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('usuario_id')->constrained('usuarios')->cascadeOnDelete();
            $table->foreignId('quadra_id')->constrained('quadras')->cascadeOnDelete();
            $table->date('data');
            $table->time('hora_inicio');
            $table->time('hora_fim');
            $table->enum('status', ['confirmada', 'cancelada'])->default('confirmada');
            $table->decimal('valor_total', 8, 2)->nullable();
            $table->text('observacao')->nullable();
            $table->timestamps();

            // Índices para consultas frequentes
            $table->index(['quadra_id', 'data', 'status']);
            $table->index(['usuario_id', 'data']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reservas');
    }
};
