<?php

namespace Database\Seeders;

use App\Models\Quadra;
use App\Models\Usuario;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            UsuarioSeeder::class,
            QuadraSeeder::class,
        ]);
    }
}
