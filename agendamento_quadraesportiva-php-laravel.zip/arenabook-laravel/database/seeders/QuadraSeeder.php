<?php

namespace Database\Seeders;

use App\Models\Quadra;
use Illuminate\Database\Seeder;

class QuadraSeeder extends Seeder
{
    public function run(): void
    {
        $quadras = [
            [
                'nome'       => 'Quadra Society 1',
                'tipo'       => 'Futebol Society',
                'descricao'  => 'Grama sintética, iluminação LED',
                'preco_hora' => 120.00,
                'capacidade' => 14,
                'emoji'      => '⚽',
            ],
            [
                'nome'       => 'Quadra de Tênis',
                'tipo'       => 'Tênis',
                'descricao'  => 'Piso em saibro, placar eletrônico',
                'preco_hora' => 80.00,
                'capacidade' => 4,
                'emoji'      => '🎾',
            ],
            [
                'nome'       => 'Quadra Basquete',
                'tipo'       => 'Basquete',
                'descricao'  => 'Piso madeira nobre, tabelas regulamentares',
                'preco_hora' => 100.00,
                'capacidade' => 10,
                'emoji'      => '🏀',
            ],
            [
                'nome'       => 'Quadra de Vôlei',
                'tipo'       => 'Vôlei de Praia',
                'descricao'  => 'Areia importada, redes profissionais',
                'preco_hora' => 90.00,
                'capacidade' => 12,
                'emoji'      => '🏐',
            ],
        ];

        foreach ($quadras as $quadra) {
            Quadra::firstOrCreate(['nome' => $quadra['nome']], $quadra);
        }
    }
}
