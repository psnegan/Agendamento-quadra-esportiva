<?php

namespace Database\Seeders;

use App\Models\Usuario;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsuarioSeeder extends Seeder
{
    public function run(): void
    {
        // Administrador padrão
        Usuario::firstOrCreate(
            ['email' => 'admin@quadra.com'],
            [
                'nome'       => 'Administrador',
                'senha_hash' => Hash::make('admin123'),
                'is_admin'   => true,
                'ativo'      => true,
            ]
        );

        // Usuário de teste
        Usuario::firstOrCreate(
            ['email' => 'usuario@quadra.com'],
            [
                'nome'       => 'Usuário Teste',
                'senha_hash' => Hash::make('user123'),
                'telefone'   => '(11) 98765-4321',
                'is_admin'   => false,
                'ativo'      => true,
            ]
        );
    }
}
