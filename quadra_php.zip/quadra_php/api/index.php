<?php
/**
 * ============================================================
 *  api/index.php  —  Roteador da API REST
 * ============================================================
 *  Todas as requisições do frontend chegam aqui.
 *  O roteamento é feito pelo parâmetro ?action=<acao>
 *
 *  Exemplos de chamada:
 *    POST  api/?action=login          corpo: {email, senha}
 *    GET   api/?action=quadras
 *    POST  api/?action=reservar       corpo: {quadra_id, data, ...}
 *    GET   api/?action=minhas_reservas
 * ============================================================
 */

// ── Bootstrap ───────────────────────────────────────────────
session_start();
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../classes/Usuario.php';
require_once __DIR__ . '/../classes/Quadra.php';
require_once __DIR__ . '/../classes/Reserva.php';

// Inicializa banco (cria tabelas + seed na primeira execução)
Database::migrate();

// ── Helpers ─────────────────────────────────────────────────
function json_ok(mixed $data): void   { echo json_encode(['ok' => true,  'data' => $data]); exit; }
function json_err(string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'erro' => $msg]);
    exit;
}
function body(): array { return json_decode(file_get_contents('php://input'), true) ?? []; }
function usuarioLogado(): ?int { return $_SESSION['usuario_id'] ?? null; }
function isAdmin(): bool       { return (bool)($_SESSION['is_admin']    ?? false); }

// ── Roteamento ──────────────────────────────────────────────
$action = $_GET['action'] ?? '';

switch ($action) {

    // ─── AUTH ────────────────────────────────────────────────

    case 'cadastro': {
        $d = body();
        if (empty($d['nome']) || empty($d['email']) || empty($d['senha'])) {
            json_err('Campos obrigatórios: nome, email, senha');
        }
        $user = Usuario::cadastrar($d['nome'], $d['email'], $d['senha'], $d['telefone'] ?? '');
        if (!$user) json_err('E-mail já cadastrado.', 409);
        json_ok($user->toArray());
    }

    case 'login': {
        $d    = body();
        $user = Usuario::autenticar($d['email'] ?? '', $d['senha'] ?? '');
        if (!$user) json_err('E-mail ou senha inválidos.', 401);
        $_SESSION['usuario_id'] = $user->id;
        $_SESSION['is_admin']   = $user->isAdmin;
        json_ok($user->toArray());
    }

    case 'logout': {
        session_destroy();
        json_ok(['mensagem' => 'Logout realizado.']);
    }

    case 'me': {
        $id = usuarioLogado();
        if (!$id) json_err('Não autenticado.', 401);
        $user = Usuario::buscarPorId($id);
        if (!$user) json_err('Usuário não encontrado.', 404);
        json_ok($user->toArray());
    }

    // ─── QUADRAS (público) ───────────────────────────────────

    case 'quadras': {
        json_ok(Quadra::ativas());
    }

    case 'horarios': {
        $quadraId = (int)($_GET['quadra_id'] ?? 0);
        $data     = $_GET['data'] ?? '';
        if (!$quadraId || !$data) json_err('Informe quadra_id e data.');
        json_ok(Quadra::horariosDisponiveis($quadraId, $data));
    }

    // ─── RESERVAS (autenticado) ──────────────────────────────

    case 'reservar': {
        $uid = usuarioLogado();
        if (!$uid) json_err('Faça login para reservar.', 401);
        $d = body();
        foreach (['quadra_id','data','hora_inicio','hora_fim'] as $campo) {
            if (empty($d[$campo])) json_err("Campo obrigatório: $campo");
        }
        $result = Reserva::criar(
            $uid, (int)$d['quadra_id'],
            $d['data'], $d['hora_inicio'], $d['hora_fim'],
            $d['observacao'] ?? ''
        );
        if (is_string($result)) json_err($result, 409);
        json_ok($result->toArray());
    }

    case 'minhas_reservas': {
        $uid = usuarioLogado();
        if (!$uid) json_err('Não autenticado.', 401);
        json_ok(Reserva::doUsuario($uid));
    }

    case 'cancelar_reserva': {
        $uid = usuarioLogado();
        if (!$uid) json_err('Não autenticado.', 401);
        $d  = body();
        $id = (int)($d['reserva_id'] ?? 0);
        if (!$id) json_err('reserva_id obrigatório.');
        $ok = Reserva::cancelar($id, $uid, isAdmin());
        if (!$ok) json_err('Reserva não encontrada ou sem permissão.', 403);
        json_ok(['mensagem' => 'Reserva cancelada.']);
    }

    // ─── ADMIN ───────────────────────────────────────────────

    case 'admin_quadras': {
        if (!isAdmin()) json_err('Acesso restrito.', 403);
        json_ok(Quadra::todas());
    }

    case 'admin_criar_quadra': {
        if (!isAdmin()) json_err('Acesso restrito.', 403);
        $d = body();
        foreach (['nome','tipo','preco_hora'] as $c) {
            if (empty($d[$c])) json_err("Campo obrigatório: $c");
        }
        $quadra = Quadra::criar($d);
        if (!$quadra) json_err('Erro ao criar quadra.');
        json_ok($quadra->toArray());
    }

    case 'admin_editar_quadra': {
        if (!isAdmin()) json_err('Acesso restrito.', 403);
        $d  = body();
        $id = (int)($d['id'] ?? 0);
        if (!$id) json_err('id obrigatório.');
        Quadra::atualizar($id, $d);
        json_ok(Quadra::buscarPorId($id)?->toArray());
    }

    case 'admin_remover_quadra': {
        if (!isAdmin()) json_err('Acesso restrito.', 403);
        $d  = body();
        $id = (int)($d['id'] ?? 0);
        if (!$id) json_err('id obrigatório.');
        json_ok(['removida' => Quadra::desativar($id)]);
    }

    case 'admin_reservas': {
        if (!isAdmin()) json_err('Acesso restrito.', 403);
        json_ok(Reserva::todas());
    }

    case 'admin_usuarios': {
        if (!isAdmin()) json_err('Acesso restrito.', 403);
        json_ok(Usuario::todos());
    }

    case 'admin_toggle_usuario': {
        if (!isAdmin()) json_err('Acesso restrito.', 403);
        $d  = body();
        $id = (int)($d['id'] ?? 0);
        json_ok(['ok' => Usuario::toggleAtivo($id)]);
    }

    case 'admin_relatorio': {
        if (!isAdmin()) json_err('Acesso restrito.', 403);
        json_ok(Reserva::relatorio());
    }

    default:
        json_err("Ação '$action' não encontrada.", 404);
}
