<?php
/**
 * ============================================================
 *  config/database.php  —  Configuração do Banco de Dados
 * ============================================================
 *
 *  USANDO SQLite (padrão, sem instalação):
 *    DB_DRIVER = 'sqlite'
 *
 *  MIGRANDO PARA MySQL Workbench:
 *    1. Crie o schema:  CREATE DATABASE quadra_esportiva;
 *    2. Altere as constantes abaixo para MySQL
 *    3. O resto do código não muda — a classe Database
 *       usa PDO, que é compatível com ambos os drivers.
 * ============================================================
 */

// ── Escolha o driver ─────────────────────────────────────────
define('DB_DRIVER',   'sqlite');          // 'sqlite' ou 'mysql'

// ── Configurações MySQL (ative quando migrar) ────────────────
define('DB_HOST',     'localhost');
define('DB_NAME',     'quadra_esportiva');
define('DB_USER',     'root');
define('DB_PASS',     '');
define('DB_CHARSET',  'utf8mb4');

// ── Caminho do arquivo SQLite ────────────────────────────────
define('SQLITE_PATH', __DIR__ . '/../data/quadra.db');


/**
 * Classe Database — Singleton para conexão PDO
 * Uso:  $pdo = Database::connect();
 */
class Database
{
    private static ?PDO $instance = null;

    /** Retorna (ou cria) a conexão PDO única. */
    public static function connect(): PDO
    {
        if (self::$instance === null) {
            self::$instance = self::createConnection();
        }
        return self::$instance;
    }

    private static function createConnection(): PDO
    {
        if (DB_DRIVER === 'sqlite') {
            $dsn = 'sqlite:' . SQLITE_PATH;
            $pdo = new PDO($dsn);
        } else {
            // MySQL — basta trocar DB_DRIVER para 'mysql' e preencher as constantes acima
            $dsn = sprintf(
                'mysql:host=%s;dbname=%s;charset=%s',
                DB_HOST, DB_NAME, DB_CHARSET
            );
            $pdo = new PDO($dsn, DB_USER, DB_PASS);
        }

        $pdo->setAttribute(PDO::ATTR_ERRMODE,            PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,   false);

        // Habilita foreign keys no SQLite
        if (DB_DRIVER === 'sqlite') {
            $pdo->exec('PRAGMA foreign_keys = ON;');
        }

        return $pdo;
    }

    /** Cria todas as tabelas se ainda não existirem. */
    public static function migrate(): void
    {
        $pdo = self::connect();

        $pdo->exec("
            CREATE TABLE IF NOT EXISTS usuarios (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                nome       TEXT    NOT NULL,
                email      TEXT    NOT NULL UNIQUE,
                senha_hash TEXT    NOT NULL,
                telefone   TEXT,
                is_admin   INTEGER NOT NULL DEFAULT 0,
                ativo      INTEGER NOT NULL DEFAULT 1,
                criado_em  TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS quadras (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                nome        TEXT    NOT NULL,
                tipo        TEXT    NOT NULL,
                descricao   TEXT,
                preco_hora  REAL    NOT NULL,
                capacidade  INTEGER,
                emoji       TEXT    DEFAULT '🏟️',
                ativa       INTEGER NOT NULL DEFAULT 1,
                criado_em   TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS reservas (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id  INTEGER NOT NULL REFERENCES usuarios(id),
                quadra_id   INTEGER NOT NULL REFERENCES quadras(id),
                data        TEXT    NOT NULL,
                hora_inicio TEXT    NOT NULL,
                hora_fim    TEXT    NOT NULL,
                status      TEXT    NOT NULL DEFAULT 'confirmada',
                valor_total REAL,
                observacao  TEXT,
                criado_em   TEXT    NOT NULL DEFAULT (datetime('now'))
            );
        ");

        // Seed: admin padrão
        $existe = $pdo->query("SELECT id FROM usuarios WHERE email='admin@quadra.com'")->fetch();
        if (!$existe) {
            $hash = password_hash('admin123', PASSWORD_BCRYPT);
            $pdo->prepare("INSERT INTO usuarios (nome,email,senha_hash,is_admin) VALUES (?,?,?,1)")
                ->execute(['Administrador', 'admin@quadra.com', $hash]);
        }

        // Seed: quadras de exemplo
        $count = $pdo->query("SELECT COUNT(*) as c FROM quadras")->fetch()['c'];
        if ($count == 0) {
            $quadras = [
                ['Quadra Society 1', 'Futebol Society', 'Grama sintética, iluminação LED', 120.0, 14, '⚽'],
                ['Quadra de Tênis',  'Tênis',           'Piso em saibro, placar eletrônico', 80.0, 4, '🎾'],
                ['Quadra Basquete',  'Basquete',        'Piso madeira nobre, tabelas regulamentares', 100.0, 10, '🏀'],
                ['Quadra de Vôlei', 'Vôlei de Praia',  'Areia importada, redes profissionais', 90.0, 12, '🏐'],
            ];
            $stmt = $pdo->prepare("INSERT INTO quadras (nome,tipo,descricao,preco_hora,capacidade,emoji) VALUES (?,?,?,?,?,?)");
            foreach ($quadras as $q) $stmt->execute($q);
        }
    }
}
