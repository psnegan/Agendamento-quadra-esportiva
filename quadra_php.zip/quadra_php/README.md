# 🏟️ ArenaBook — Sistema de Agendamento de Quadra Esportiva

## Estrutura do Projeto

```
quadra_php/
│
├── index.html              ← Frontend completo (HTML + CSS + JS)
├── README.md
│
├── api/
│   └── index.php           ← Roteador REST (todas as requisições chegam aqui)
│
├── config/
│   └── database.php        ← Conexão PDO (SQLite ou MySQL)
│
├── classes/
│   ├── Usuario.php         ← Modelo: autenticação, CRUD
│   ├── Quadra.php          ← Modelo: quadras, horários disponíveis
│   └── Reserva.php         ← Modelo: agendamentos, cancelamentos, relatório
│
└── data/
    └── quadra.db           ← Criado automaticamente (SQLite)
```

---

## 🚀 Como Rodar

### Opção 1 — PHP embutido (sem configuração)
```bash
cd quadra_php
php -S localhost:8000
# Abra: http://localhost:8000
```

### Opção 2 — XAMPP/WAMP/Laragon
Copie a pasta para `htdocs/` ou `www/` e acesse:
```
http://localhost/quadra_php/
```

### Credenciais padrão
| Campo | Valor            |
|-------|------------------|
| Email | admin@quadra.com |
| Senha | admin123         |

---

## 🔌 Migração para MySQL Workbench (3 passos)

### 1. Criar o banco
```sql
-- No MySQL Workbench:
CREATE DATABASE quadra_esportiva
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
```

### 2. Editar `config/database.php`
```php
// Linha atual:
define('DB_DRIVER', 'sqlite');

// Altere para:
define('DB_DRIVER', 'mysql');

// E preencha:
define('DB_HOST', 'localhost');
define('DB_NAME', 'quadra_esportiva');
define('DB_USER', 'root');         // seu usuário MySQL
define('DB_PASS', 'sua_senha');    // sua senha MySQL
```

### 3. Reiniciar o servidor
```bash
php -S localhost:8000
```
✅ As tabelas são criadas automaticamente pelo `Database::migrate()`.

---

## 📡 Endpoints da API

Todas as chamadas vão para `api/index.php?action=<acao>`

### Autenticação
| Ação         | Método | Corpo                        | Descrição     |
|--------------|--------|------------------------------|---------------|
| `cadastro`   | POST   | nome, email, senha, telefone | Criar conta   |
| `login`      | POST   | email, senha                 | Fazer login   |
| `logout`     | POST   | —                            | Encerrar sessão|
| `me`         | GET    | —                            | Usuário atual |

### Quadras (público)
| Ação        | Método | Parâmetros                   | Descrição              |
|-------------|--------|------------------------------|------------------------|
| `quadras`   | GET    | —                            | Listar quadras ativas  |
| `horarios`  | GET    | quadra_id, data (YYYY-MM-DD) | Horários disponíveis   |

### Reservas (autenticado)
| Ação                | Método | Corpo                                    | Descrição         |
|---------------------|--------|------------------------------------------|-------------------|
| `reservar`          | POST   | quadra_id, data, hora_inicio, hora_fim   | Criar reserva     |
| `minhas_reservas`   | GET    | —                                        | Histórico pessoal |
| `cancelar_reserva`  | POST   | reserva_id                               | Cancelar          |

### Admin
| Ação                    | Método | Descrição               |
|-------------------------|--------|-------------------------|
| `admin_quadras`         | GET    | Todas as quadras        |
| `admin_criar_quadra`    | POST   | Nova quadra             |
| `admin_editar_quadra`   | POST   | Editar quadra           |
| `admin_remover_quadra`  | POST   | Desativar quadra        |
| `admin_reservas`        | GET    | Todas as reservas       |
| `admin_usuarios`        | GET    | Todos os usuários       |
| `admin_toggle_usuario`  | POST   | Ativar/desativar user   |
| `admin_relatorio`       | GET    | Estatísticas gerais     |

---

## 🗂️ Estrutura de Classes (UML)

Ver arquivo `uml_classes.svg` para o diagrama completo.

### Resumo das Classes

**Database** (Singleton)
- `connect(): PDO` — retorna conexão única
- `migrate(): void` — cria tabelas + seed

**Usuario**
- Propriedades: id, nome, email, senhaHash, telefone, isAdmin, ativo
- `cadastrar()`, `autenticar()`, `buscarPorId()`, `todos()`, `toggleAtivo()`

**Quadra**
- Propriedades: id, nome, tipo, descricao, precoHora, capacidade, emoji, ativa
- `ativas()`, `todas()`, `criar()`, `atualizar()`, `desativar()`, `horariosDisponiveis()`

**Reserva**
- Propriedades: id, usuarioId, quadraId, data, horaInicio, horaFim, status, valorTotal
- `criar()`, `doUsuario()`, `todas()`, `cancelar()`, `relatorio()`
