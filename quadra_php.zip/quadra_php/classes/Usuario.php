<?php
/**
 * ============================================================
 *  classes/Usuario.php  —  Modelo de Usuário
 * ============================================================
 *  Representa um usuário do sistema (cliente ou administrador).
 *  Encapsula toda lógica de autenticação e CRUD de usuários.
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Usuario
{
    // ── Propriedades (mapeiam colunas da tabela) ─────────────
    public int    $id;
    public string $nome;
    public string $email;
    public string $senhaHash;
    public string $telefone;
    public bool   $isAdmin;
    public bool   $ativo;
    public string $criadoEm;

    // ── Construtor ──────────────────────────────────────────
    public function __construct(array $dados = [])
    {
        $this->id        = $dados['id']        ?? 0;
        $this->nome      = $dados['nome']      ?? '';
        $this->email     = $dados['email']     ?? '';
        $this->senhaHash = $dados['senha_hash'] ?? '';
        $this->telefone  = $dados['telefone']  ?? '';
        $this->isAdmin   = (bool)($dados['is_admin'] ?? false);
        $this->ativo     = (bool)($dados['ativo']    ?? true);
        $this->criadoEm  = $dados['criado_em'] ?? '';
    }

    // ── Conversão para array (resposta JSON) ────────────────
    public function toArray(): array
    {
        return [
            'id'        => $this->id,
            'nome'      => $this->nome,
            'email'     => $this->email,
            'telefone'  => $this->telefone,
            'is_admin'  => $this->isAdmin,
            'ativo'     => $this->ativo,
            'criado_em' => $this->criadoEm,
        ];
    }

    // ══════════════════════════════════════════════════════════
    //  MÉTODOS ESTÁTICOS  (operações no banco)
    // ══════════════════════════════════════════════════════════

    /** Cadastra um novo usuário. Retorna o Usuario criado ou null em caso de erro. */
    public static function cadastrar(string $nome, string $email, string $senha, string $telefone = ''): ?self
    {
        $pdo = Database::connect();

        // Verifica e-mail duplicado
        $existe = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
        $existe->execute([$email]);
        if ($existe->fetch()) return null;

        $hash = password_hash($senha, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare(
            "INSERT INTO usuarios (nome, email, senha_hash, telefone) VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$nome, $email, $hash, $telefone]);

        return self::buscarPorId((int)$pdo->lastInsertId());
    }

    /** Autentica email + senha. Retorna Usuario ou null. */
    public static function autenticar(string $email, string $senha): ?self
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? AND ativo = 1");
        $stmt->execute([$email]);
        $row  = $stmt->fetch();

        if ($row && password_verify($senha, $row['senha_hash'])) {
            return new self($row);
        }
        return null;
    }

    /** Busca um usuário pelo ID. */
    public static function buscarPorId(int $id): ?self
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
        $stmt->execute([$id]);
        $row  = $stmt->fetch();
        return $row ? new self($row) : null;
    }

    /** Retorna todos os usuários (para o admin). */
    public static function todos(): array
    {
        $pdo  = Database::connect();
        $rows = $pdo->query("SELECT * FROM usuarios ORDER BY criado_em DESC")->fetchAll();
        return array_map(fn($r) => (new self($r))->toArray(), $rows);
    }

    /** Ativa ou desativa um usuário. */
    public static function toggleAtivo(int $id): bool
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare("UPDATE usuarios SET ativo = CASE WHEN ativo=1 THEN 0 ELSE 1 END WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }
}
