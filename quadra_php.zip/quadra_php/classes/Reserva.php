<?php
/**
 * ============================================================
 *  classes/Reserva.php  —  Modelo de Reserva
 * ============================================================
 *  Controla o agendamento: criação, cancelamento, histórico
 *  e detecção de conflitos de horário.
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Reserva
{
    // ── Propriedades ─────────────────────────────────────────
    public int    $id;
    public int    $usuarioId;
    public int    $quadraId;
    public string $data;
    public string $horaInicio;
    public string $horaFim;
    public string $status;       // 'confirmada' | 'cancelada'
    public float  $valorTotal;
    public string $observacao;
    public string $criadoEm;
    // Campos extras (JOINs)
    public string $usuarioNome  = '';
    public string $quadraNome   = '';
    public string $quadraEmoji  = '';

    // ── Construtor ──────────────────────────────────────────
    public function __construct(array $dados = [])
    {
        $this->id          = $dados['id']           ?? 0;
        $this->usuarioId   = $dados['usuario_id']   ?? 0;
        $this->quadraId    = $dados['quadra_id']    ?? 0;
        $this->data        = $dados['data']          ?? '';
        $this->horaInicio  = $dados['hora_inicio']  ?? '';
        $this->horaFim     = $dados['hora_fim']      ?? '';
        $this->status      = $dados['status']        ?? 'confirmada';
        $this->valorTotal  = (float)($dados['valor_total'] ?? 0);
        $this->observacao  = $dados['observacao']   ?? '';
        $this->criadoEm    = $dados['criado_em']    ?? '';
        $this->usuarioNome = $dados['usuario_nome'] ?? '';
        $this->quadraNome  = $dados['quadra_nome']  ?? '';
        $this->quadraEmoji = $dados['quadra_emoji'] ?? '';
    }

    public function toArray(): array
    {
        return [
            'id'           => $this->id,
            'usuario_id'   => $this->usuarioId,
            'usuario_nome' => $this->usuarioNome,
            'quadra_id'    => $this->quadraId,
            'quadra_nome'  => $this->quadraNome,
            'quadra_emoji' => $this->quadraEmoji,
            'data'         => $this->data,
            'hora_inicio'  => $this->horaInicio,
            'hora_fim'     => $this->horaFim,
            'status'       => $this->status,
            'valor_total'  => $this->valorTotal,
            'observacao'   => $this->observacao,
            'criado_em'    => $this->criadoEm,
        ];
    }

    // ══════════════════════════════════════════════════════════
    //  MÉTODOS ESTÁTICOS
    // ══════════════════════════════════════════════════════════

    /** Cria uma reserva. Retorna a Reserva criada ou string de erro. */
    public static function criar(
        int    $usuarioId,
        int    $quadraId,
        string $data,
        string $horaInicio,
        string $horaFim,
        string $observacao = ''
    ): Reserva|string
    {
        // Não permite datas no passado
        if ($data < date('Y-m-d')) {
            return 'Não é possível reservar datas no passado.';
        }

        // Verifica conflito de horário
        $pdo  = Database::connect();
        $stmt = $pdo->prepare(
            "SELECT id FROM reservas
              WHERE quadra_id=? AND data=? AND status='confirmada'
                AND hora_inicio < ? AND hora_fim > ?"
        );
        $stmt->execute([$quadraId, $data, $horaFim, $horaInicio]);
        if ($stmt->fetch()) {
            return 'Horário já reservado para essa quadra.';
        }

        // Calcula valor
        $horas = (int)substr($horaFim,0,2) - (int)substr($horaInicio,0,2);
        $quadraRow = $pdo->prepare("SELECT preco_hora FROM quadras WHERE id=?");
        $quadraRow->execute([$quadraId]);
        $preco = (float)($quadraRow->fetch()['preco_hora'] ?? 0);
        $valor = $preco * $horas;

        // Insere
        $ins = $pdo->prepare(
            "INSERT INTO reservas (usuario_id,quadra_id,data,hora_inicio,hora_fim,valor_total,observacao)
             VALUES (?,?,?,?,?,?,?)"
        );
        $ins->execute([$usuarioId, $quadraId, $data, $horaInicio, $horaFim, $valor, $observacao]);

        return self::buscarPorId((int)$pdo->lastInsertId());
    }

    /** Busca reserva por ID com JOIN de nomes. */
    public static function buscarPorId(int $id): ?self
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare(
            "SELECT r.*, u.nome AS usuario_nome, q.nome AS quadra_nome, q.emoji AS quadra_emoji
               FROM reservas r
               JOIN usuarios u ON u.id = r.usuario_id
               JOIN quadras  q ON q.id = r.quadra_id
              WHERE r.id = ?"
        );
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ? new self($row) : null;
    }

    /** Histórico de reservas de um usuário. */
    public static function doUsuario(int $usuarioId): array
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare(
            "SELECT r.*, u.nome AS usuario_nome, q.nome AS quadra_nome, q.emoji AS quadra_emoji
               FROM reservas r
               JOIN usuarios u ON u.id = r.usuario_id
               JOIN quadras  q ON q.id = r.quadra_id
              WHERE r.usuario_id = ?
           ORDER BY r.data DESC, r.hora_inicio DESC"
        );
        $stmt->execute([$usuarioId]);
        return array_map(fn($row) => (new self($row))->toArray(), $stmt->fetchAll());
    }

    /** Todas as reservas (admin). */
    public static function todas(): array
    {
        $pdo  = Database::connect();
        $rows = $pdo->query(
            "SELECT r.*, u.nome AS usuario_nome, q.nome AS quadra_nome, q.emoji AS quadra_emoji
               FROM reservas r
               JOIN usuarios u ON u.id = r.usuario_id
               JOIN quadras  q ON q.id = r.quadra_id
           ORDER BY r.data DESC, r.hora_inicio DESC"
        )->fetchAll();
        return array_map(fn($row) => (new self($row))->toArray(), $rows);
    }

    /** Cancela uma reserva. Retorna true se bem-sucedido. */
    public static function cancelar(int $id, int $usuarioId, bool $isAdmin = false): bool
    {
        $pdo  = Database::connect();
        if ($isAdmin) {
            $stmt = $pdo->prepare("UPDATE reservas SET status='cancelada' WHERE id=?");
            $stmt->execute([$id]);
        } else {
            $stmt = $pdo->prepare("UPDATE reservas SET status='cancelada' WHERE id=? AND usuario_id=?");
            $stmt->execute([$id, $usuarioId]);
        }
        return $stmt->rowCount() > 0;
    }

    /** Relatório resumido para o admin. */
    public static function relatorio(): array
    {
        $pdo = Database::connect();

        $total      = (int)$pdo->query("SELECT COUNT(*) FROM reservas")->fetchColumn();
        $ativas     = (int)$pdo->query("SELECT COUNT(*) FROM reservas WHERE status='confirmada'")->fetchColumn();
        $canceladas = (int)$pdo->query("SELECT COUNT(*) FROM reservas WHERE status='cancelada'")->fetchColumn();
        $receita    = (float)$pdo->query("SELECT COALESCE(SUM(valor_total),0) FROM reservas WHERE status='confirmada'")->fetchColumn();
        $usuarios   = (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE is_admin=0")->fetchColumn();
        $quadras    = (int)$pdo->query("SELECT COUNT(*) FROM quadras WHERE ativa=1")->fetchColumn();

        // Quadra mais reservada
        $top = $pdo->query(
            "SELECT q.nome, COUNT(r.id) as total
               FROM reservas r JOIN quadras q ON q.id=r.quadra_id
              WHERE r.status='confirmada'
           GROUP BY q.id ORDER BY total DESC LIMIT 1"
        )->fetch();

        return [
            'total_reservas'        => $total,
            'reservas_ativas'       => $ativas,
            'reservas_canceladas'   => $canceladas,
            'receita_total'         => round($receita, 2),
            'total_usuarios'        => $usuarios,
            'total_quadras'         => $quadras,
            'quadra_mais_reservada' => $top ? $top['nome'] : 'N/A',
        ];
    }
}
