<?php
/**
 * ============================================================
 *  classes/Quadra.php  —  Modelo de Quadra Esportiva
 * ============================================================
 *  Gerencia quadras: listagem, CRUD pelo admin e consulta
 *  de horários disponíveis em uma data específica.
 * ============================================================
 */

require_once __DIR__ . '/../config/database.php';

class Quadra
{
    // ── Propriedades ─────────────────────────────────────────
    public int    $id;
    public string $nome;
    public string $tipo;
    public string $descricao;
    public float  $precoHora;
    public int    $capacidade;
    public string $emoji;
    public bool   $ativa;
    public string $criadoEm;

    // ── Construtor ──────────────────────────────────────────
    public function __construct(array $dados = [])
    {
        $this->id         = $dados['id']         ?? 0;
        $this->nome       = $dados['nome']        ?? '';
        $this->tipo       = $dados['tipo']        ?? '';
        $this->descricao  = $dados['descricao']   ?? '';
        $this->precoHora  = (float)($dados['preco_hora'] ?? 0);
        $this->capacidade = (int)($dados['capacidade']   ?? 0);
        $this->emoji      = $dados['emoji']       ?? '🏟️';
        $this->ativa      = (bool)($dados['ativa']       ?? true);
        $this->criadoEm   = $dados['criado_em']   ?? '';
    }

    public function toArray(): array
    {
        return [
            'id'         => $this->id,
            'nome'       => $this->nome,
            'tipo'       => $this->tipo,
            'descricao'  => $this->descricao,
            'preco_hora' => $this->precoHora,
            'capacidade' => $this->capacidade,
            'emoji'      => $this->emoji,
            'ativa'      => $this->ativa,
        ];
    }

    // ══════════════════════════════════════════════════════════
    //  MÉTODOS ESTÁTICOS
    // ══════════════════════════════════════════════════════════

    /** Lista todas as quadras ativas. */
    public static function ativas(): array
    {
        $pdo  = Database::connect();
        $rows = $pdo->query("SELECT * FROM quadras WHERE ativa=1 ORDER BY nome")->fetchAll();
        return array_map(fn($r) => (new self($r))->toArray(), $rows);
    }

    /** Lista TODAS as quadras (admin). */
    public static function todas(): array
    {
        $pdo  = Database::connect();
        $rows = $pdo->query("SELECT * FROM quadras ORDER BY nome")->fetchAll();
        return array_map(fn($r) => (new self($r))->toArray(), $rows);
    }

    /** Busca por ID. */
    public static function buscarPorId(int $id): ?self
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare("SELECT * FROM quadras WHERE id = ?");
        $stmt->execute([$id]);
        $row  = $stmt->fetch();
        return $row ? new self($row) : null;
    }

    /** Cria uma nova quadra. */
    public static function criar(array $dados): ?self
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare(
            "INSERT INTO quadras (nome,tipo,descricao,preco_hora,capacidade,emoji) VALUES (?,?,?,?,?,?)"
        );
        $stmt->execute([
            $dados['nome'], $dados['tipo'],
            $dados['descricao'] ?? '',
            (float)$dados['preco_hora'],
            (int)($dados['capacidade'] ?? 0),
            $dados['emoji'] ?? '🏟️',
        ]);
        return self::buscarPorId((int)$pdo->lastInsertId());
    }

    /** Atualiza uma quadra. */
    public static function atualizar(int $id, array $dados): bool
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare(
            "UPDATE quadras SET nome=?,tipo=?,descricao=?,preco_hora=?,capacidade=?,emoji=?,ativa=? WHERE id=?"
        );
        return $stmt->execute([
            $dados['nome'], $dados['tipo'],
            $dados['descricao'] ?? '',
            (float)$dados['preco_hora'],
            (int)($dados['capacidade'] ?? 0),
            $dados['emoji'] ?? '🏟️',
            isset($dados['ativa']) ? (int)$dados['ativa'] : 1,
            $id,
        ]);
    }

    /** Soft-delete: desativa a quadra (mantém histórico). */
    public static function desativar(int $id): bool
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare("UPDATE quadras SET ativa=0 WHERE id=?");
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

    /**
     * Retorna os horários do dia (07–21h) com flag disponivel.
     * Horários com reservas confirmadas ficam marcados como ocupados.
     */
    public static function horariosDisponiveis(int $quadraId, string $data): array
    {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare(
            "SELECT hora_inicio, hora_fim FROM reservas
              WHERE quadra_id=? AND data=? AND status='confirmada'"
        );
        $stmt->execute([$quadraId, $data]);
        $reservas = $stmt->fetchAll();

        // Marca horas ocupadas
        $ocupados = [];
        foreach ($reservas as $r) {
            $h = (int)substr($r['hora_inicio'], 0, 2);
            while ($h < (int)substr($r['hora_fim'], 0, 2)) {
                $ocupados[] = sprintf('%02d:00', $h);
                $h++;
            }
        }

        $horarios = [];
        for ($h = 7; $h < 22; $h++) {
            $slot = sprintf('%02d:00', $h);
            $horarios[] = ['horario' => $slot, 'disponivel' => !in_array($slot, $ocupados)];
        }
        return $horarios;
    }
}
