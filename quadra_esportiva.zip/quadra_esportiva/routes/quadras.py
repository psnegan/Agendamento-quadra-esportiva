"""
=============================================================
  routes/quadras.py  –  Listagem e consulta de quadras
=============================================================
"""

from flask import Blueprint, request, jsonify, session
from database import db, Quadra, Reserva
from datetime import date, datetime

quadras_bp = Blueprint("quadras", __name__)


@quadras_bp.route("/", methods=["GET"])
def listar_quadras():
    """Retorna todas as quadras ativas."""
    quadras = Quadra.query.filter_by(ativa=True).all()
    return jsonify({"quadras": [q.to_dict() for q in quadras]})


@quadras_bp.route("/<int:quadra_id>", methods=["GET"])
def detalhe_quadra(quadra_id):
    """Retorna os detalhes de uma quadra específica."""
    quadra = Quadra.query.get_or_404(quadra_id)
    return jsonify({"quadra": quadra.to_dict()})


@quadras_bp.route("/<int:quadra_id>/horarios", methods=["GET"])
def horarios_disponiveis(quadra_id):
    """
    Retorna os horários disponíveis de uma quadra em uma data específica.
    Parâmetro de query: ?data=2024-12-25
    """
    data_str = request.args.get("data")
    if not data_str:
        return jsonify({"erro": "Informe a data no formato YYYY-MM-DD"}), 400

    try:
        data_consulta = date.fromisoformat(data_str)
    except ValueError:
        return jsonify({"erro": "Data inválida"}), 400

    # Horários de funcionamento: 07:00 às 22:00
    horarios_funcionamento = [
        f"{h:02d}:00" for h in range(7, 22)
    ]

    # Busca reservas confirmadas na data
    reservas_do_dia = Reserva.query.filter_by(
        quadra_id=quadra_id, data=data_consulta, status="confirmada"
    ).all()

    horarios_ocupados = set()
    for reserva in reservas_do_dia:
        hora = reserva.hora_inicio.hour
        while hora < reserva.hora_fim.hour:
            horarios_ocupados.add(f"{hora:02d}:00")
            hora += 1

    resultado = [
        {"horario": h, "disponivel": h not in horarios_ocupados}
        for h in horarios_funcionamento
    ]

    return jsonify({"data": data_str, "horarios": resultado})
