"""
=============================================================
  routes/reservas.py  –  Agendamento e cancelamento
=============================================================
"""

from flask import Blueprint, request, jsonify, session
from database import db, Reserva, Quadra
from datetime import date, time, datetime

reservas_bp = Blueprint("reservas", __name__)


def usuario_logado():
    """Helper: retorna o ID do usuário na sessão ou None."""
    return session.get("usuario_id")


@reservas_bp.route("/", methods=["POST"])
def criar_reserva():
    """Cria uma nova reserva de quadra."""
    uid = usuario_logado()
    if not uid:
        return jsonify({"erro": "Faça login para reservar"}), 401

    dados = request.get_json()
    campos = ["quadra_id", "data", "hora_inicio", "hora_fim"]
    for campo in campos:
        if not dados.get(campo):
            return jsonify({"erro": f"Campo '{campo}' é obrigatório"}), 400

    try:
        data_reserva   = date.fromisoformat(dados["data"])
        hora_ini       = time.fromisoformat(dados["hora_inicio"])
        hora_fim       = time.fromisoformat(dados["hora_fim"])
    except ValueError:
        return jsonify({"erro": "Formato de data/hora inválido"}), 400

    if hora_ini >= hora_fim:
        return jsonify({"erro": "Hora de início deve ser anterior à hora de fim"}), 400

    if data_reserva < date.today():
        return jsonify({"erro": "Não é possível reservar datas no passado"}), 400

    # Verifica conflito com reservas existentes
    conflito = Reserva.query.filter(
        Reserva.quadra_id == dados["quadra_id"],
        Reserva.data      == data_reserva,
        Reserva.status    == "confirmada",
        Reserva.hora_inicio < hora_fim,
        Reserva.hora_fim    > hora_ini
    ).first()

    if conflito:
        return jsonify({"erro": "Horário já reservado para essa quadra"}), 409

    # Calcula o valor total
    quadra  = Quadra.query.get(dados["quadra_id"])
    horas   = (hora_fim.hour - hora_ini.hour)
    valor   = quadra.preco_hora * horas

    nova_reserva = Reserva(
        usuario_id=uid,
        quadra_id=dados["quadra_id"],
        data=data_reserva,
        hora_inicio=hora_ini,
        hora_fim=hora_fim,
        valor_total=valor,
        observacao=dados.get("observacao", "")
    )
    db.session.add(nova_reserva)
    db.session.commit()

    return jsonify({
        "mensagem": "Reserva criada com sucesso!",
        "reserva": nova_reserva.to_dict()
    }), 201


@reservas_bp.route("/minhas", methods=["GET"])
def minhas_reservas():
    """Retorna o histórico de reservas do usuário logado."""
    uid = usuario_logado()
    if not uid:
        return jsonify({"erro": "Faça login para ver suas reservas"}), 401

    reservas = Reserva.query.filter_by(usuario_id=uid)\
                            .order_by(Reserva.data.desc(), Reserva.hora_inicio.desc())\
                            .all()

    return jsonify({"reservas": [r.to_dict() for r in reservas]})


@reservas_bp.route("/<int:reserva_id>/cancelar", methods=["PUT"])
def cancelar_reserva(reserva_id):
    """Cancela uma reserva do usuário logado."""
    uid = usuario_logado()
    if not uid:
        return jsonify({"erro": "Faça login para cancelar reservas"}), 401

    reserva = Reserva.query.get_or_404(reserva_id)

    # Usuário só pode cancelar as próprias reservas (admin pode cancelar qualquer uma)
    if reserva.usuario_id != uid and not session.get("is_admin"):
        return jsonify({"erro": "Acesso negado"}), 403

    if reserva.status == "cancelada":
        return jsonify({"erro": "Reserva já está cancelada"}), 400

    reserva.status = "cancelada"
    db.session.commit()

    return jsonify({"mensagem": "Reserva cancelada com sucesso!", "reserva": reserva.to_dict()})
