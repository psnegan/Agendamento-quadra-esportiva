"""
=============================================================
  routes/auth.py  –  Autenticação (login / cadastro / logout)
=============================================================
"""

from flask import Blueprint, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from database import db, Usuario

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/cadastro", methods=["POST"])
def cadastro():
    """Cadastra um novo usuário."""
    dados = request.get_json()

    # Validações básicas
    campos = ["nome", "email", "senha"]
    for campo in campos:
        if not dados.get(campo):
            return jsonify({"erro": f"Campo '{campo}' é obrigatório"}), 400

    if Usuario.query.filter_by(email=dados["email"]).first():
        return jsonify({"erro": "E-mail já cadastrado"}), 409

    novo_usuario = Usuario(
        nome=dados["nome"],
        email=dados["email"],
        senha_hash=generate_password_hash(dados["senha"]),
        telefone=dados.get("telefone", "")
    )
    db.session.add(novo_usuario)
    db.session.commit()

    return jsonify({"mensagem": "Usuário cadastrado com sucesso!", "usuario": novo_usuario.to_dict()}), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    """Autentica um usuário e cria uma sessão."""
    dados = request.get_json()
    email = dados.get("email")
    senha = dados.get("senha")

    usuario = Usuario.query.filter_by(email=email).first()

    if not usuario or not check_password_hash(usuario.senha_hash, senha):
        return jsonify({"erro": "E-mail ou senha inválidos"}), 401

    if not usuario.ativo:
        return jsonify({"erro": "Usuário inativo. Entre em contato com o administrador"}), 403

    # Salva dados na sessão do Flask
    session["usuario_id"] = usuario.id
    session["is_admin"]   = usuario.is_admin

    return jsonify({
        "mensagem": "Login realizado com sucesso!",
        "usuario": usuario.to_dict()
    })


@auth_bp.route("/logout", methods=["POST"])
def logout():
    """Encerra a sessão do usuário."""
    session.clear()
    return jsonify({"mensagem": "Logout realizado com sucesso!"})


@auth_bp.route("/me", methods=["GET"])
def me():
    """Retorna os dados do usuário logado."""
    usuario_id = session.get("usuario_id")
    if not usuario_id:
        return jsonify({"erro": "Não autenticado"}), 401

    usuario = Usuario.query.get(usuario_id)
    if not usuario:
        return jsonify({"erro": "Usuário não encontrado"}), 404

    return jsonify({"usuario": usuario.to_dict()})
