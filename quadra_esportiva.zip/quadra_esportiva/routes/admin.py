"""
=============================================================
  routes/admin.py  –  Painel administrativo
=============================================================
"""

from flask import Blueprint, request, jsonify, session
from werkzeug.security import generate_password_hash
from database import db, Usuario, Quadra, Reserva
from datetime import date
from sqlalchemy import func

admin_bp = Blueprint("admin", __name__)


def verificar_admin():
    """Retorna True se o usuário logado for administrador."""
    return session.get("is_admin", False)


# ─── QUADRAS ────────────────────────────────────────────────

@admin_bp.route("/quadras", methods=["POST"])
def criar_quadra():
    """Cria uma nova quadra."""
    if not verificar_admin():
        return jsonify({"erro": "Acesso restrito ao administrador"}), 403

    dados = request.get_json()
    for campo in ["nome", "tipo", "preco_hora"]:
        if not dados.get(campo):
            return jsonify({"erro": f"Campo '{campo}' é obrigatório"}), 400

    quadra = Quadra(
        nome=dados["nome"], tipo=dados["tipo"],
        descricao=dados.get("descricao", ""),
        preco_hora=float(dados["preco_hora"]),
        capacidade=dados.get("capacidade"),
        foto_url=dados.get("foto_url", "🏟️")
    )
    db.session.add(quadra)
    db.session.commit()
    return jsonify({"mensagem": "Quadra criada!", "quadra": quadra.to_dict()}), 201


@admin_bp.route("/quadras/<int:quadra_id>", methods=["PUT"])
def editar_quadra(quadra_id):
    """Edita uma quadra existente."""
    if not verificar_admin():
        return jsonify({"erro": "Acesso restrito ao administrador"}), 403

    quadra = Quadra.query.get_or_404(quadra_id)
    dados  = request.get_json()

    quadra.nome       = dados.get("nome",       quadra.nome)
    quadra.tipo       = dados.get("tipo",       quadra.tipo)
    quadra.descricao  = dados.get("descricao",  quadra.descricao)
    quadra.preco_hora = dados.get("preco_hora", quadra.preco_hora)
    quadra.capacidade = dados.get("capacidade", quadra.capacidade)
    quadra.foto_url   = dados.get("foto_url",   quadra.foto_url)
    quadra.ativa      = dados.get("ativa",      quadra.ativa)

    db.session.commit()
    return jsonify({"mensagem": "Quadra atualizada!", "quadra": quadra.to_dict()})


@admin_bp.route("/quadras/<int:quadra_id>", methods=["DELETE"])
def remover_quadra(quadra_id):
    """Desativa uma quadra (soft delete – mantém histórico)."""
    if not verificar_admin():
        return jsonify({"erro": "Acesso restrito ao administrador"}), 403

    quadra = Quadra.query.get_or_404(quadra_id)
    quadra.ativa = False
    db.session.commit()
    return jsonify({"mensagem": "Quadra desativada com sucesso!"})


# ─── RESERVAS ───────────────────────────────────────────────

@admin_bp.route("/reservas", methods=["GET"])
def todas_reservas():
    """Retorna todas as reservas do sistema."""
    if not verificar_admin():
        return jsonify({"erro": "Acesso restrito ao administrador"}), 403

    reservas = Reserva.query.order_by(Reserva.data.desc()).all()
    return jsonify({"reservas": [r.to_dict() for r in reservas]})


# ─── USUÁRIOS ───────────────────────────────────────────────

@admin_bp.route("/usuarios", methods=["GET"])
def listar_usuarios():
    """Lista todos os usuários."""
    if not verificar_admin():
        return jsonify({"erro": "Acesso restrito ao administrador"}), 403

    usuarios = Usuario.query.order_by(Usuario.criado_em.desc()).all()
    return jsonify({"usuarios": [u.to_dict() for u in usuarios]})


@admin_bp.route("/usuarios/<int:usuario_id>/toggle", methods=["PUT"])
def toggle_usuario(usuario_id):
    """Ativa ou desativa um usuário."""
    if not verificar_admin():
        return jsonify({"erro": "Acesso restrito ao administrador"}), 403

    usuario = Usuario.query.get_or_404(usuario_id)
    usuario.ativo = not usuario.ativo
    db.session.commit()

    status = "ativado" if usuario.ativo else "desativado"
    return jsonify({"mensagem": f"Usuário {status} com sucesso!", "usuario": usuario.to_dict()})


# ─── RELATÓRIOS ─────────────────────────────────────────────

@admin_bp.route("/relatorio", methods=["GET"])
def relatorio():
    """Retorna estatísticas gerais de uso das quadras."""
    if not verificar_admin():
        return jsonify({"erro": "Acesso restrito ao administrador"}), 403

    total_reservas    = Reserva.query.count()
    reservas_ativas   = Reserva.query.filter_by(status="confirmada").count()
    reservas_canceladas = Reserva.query.filter_by(status="cancelada").count()
    total_usuarios    = Usuario.query.filter_by(is_admin=False).count()
    total_quadras     = Quadra.query.filter_by(ativa=True).count()

    # Receita total (apenas reservas confirmadas)
    receita = db.session.query(func.sum(Reserva.valor_total))\
                        .filter(Reserva.status == "confirmada").scalar() or 0

    # Quadra mais reservada
    mais_reservada = db.session.query(
        Quadra.nome, func.count(Reserva.id).label("total")
    ).join(Reserva).filter(Reserva.status == "confirmada")\
     .group_by(Quadra.id).order_by(func.count(Reserva.id).desc()).first()

    return jsonify({
        "total_reservas": total_reservas,
        "reservas_ativas": reservas_ativas,
        "reservas_canceladas": reservas_canceladas,
        "total_usuarios": total_usuarios,
        "total_quadras": total_quadras,
        "receita_total": round(receita, 2),
        "quadra_mais_reservada": mais_reservada[0] if mais_reservada else "N/A"
    })
