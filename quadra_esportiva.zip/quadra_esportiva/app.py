"""
=============================================================
  SISTEMA DE AGENDAMENTO DE QUADRA ESPORTIVA
  Backend: Flask (Python)
  Banco de dados: SQLite (fácil migração para MySQL Workbench)
=============================================================

MIGRAÇÃO PARA MYSQL:
  1. pip install mysql-connector-python
  2. Troque a linha de conexão no arquivo database.py:
     - SQLite:  sqlite:///quadra.db
     - MySQL:   mysql+mysqlconnector://usuario:senha@localhost/quadra_esportiva
  3. No MySQL Workbench: crie o schema 'quadra_esportiva' e rode a aplicação.
     As tabelas serão criadas automaticamente pelo SQLAlchemy.
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os

from database import db, init_db
from routes.auth import auth_bp
from routes.quadras import quadras_bp
from routes.reservas import reservas_bp
from routes.admin import admin_bp

# ─── Configuração do App ────────────────────────────────────
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = "quadra-secret-2024"

# ── Banco de dados (SQLite por padrão – veja comentário no topo para MySQL) ──
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///quadra.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

CORS(app)           # Permite chamadas do frontend
db.init_app(app)    # Inicializa o SQLAlchemy

# ─── Registro dos Blueprints (rotas agrupadas por domínio) ──
app.register_blueprint(auth_bp,    url_prefix="/api/auth")
app.register_blueprint(quadras_bp, url_prefix="/api/quadras")
app.register_blueprint(reservas_bp,url_prefix="/api/reservas")
app.register_blueprint(admin_bp,   url_prefix="/api/admin")

# ─── Servir o Frontend ──────────────────────────────────────
@app.route("/")
@app.route("/<path:path>")
def frontend(path="index.html"):
    """Serve os arquivos estáticos do frontend."""
    if path and os.path.exists(os.path.join("static", path)):
        return send_from_directory("static", path)
    return send_from_directory("static", "index.html")

# ─── Inicialização ──────────────────────────────────────────
with app.app_context():
    init_db()   # Cria tabelas + dados iniciais (admin padrão)

if __name__ == "__main__":
    print("🏟️  Servidor iniciado em http://localhost:5000")
    app.run(debug=True, port=5000)
