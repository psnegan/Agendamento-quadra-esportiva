"""
=============================================================
  database.py  –  Modelos e inicialização do banco de dados
=============================================================
  ORM: SQLAlchemy (compatível com SQLite e MySQL sem mudanças)
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date, time
from werkzeug.security import generate_password_hash

db = SQLAlchemy()

# ─────────────────────────────────────────────────────────────
#  MODELOS (cada classe = uma tabela no banco)
# ─────────────────────────────────────────────────────────────

class Usuario(db.Model):
    """Usuários do sistema (clientes e administradores)."""
    __tablename__ = "usuarios"

    id         = db.Column(db.Integer, primary_key=True)
    nome       = db.Column(db.String(100), nullable=False)
    email      = db.Column(db.String(150), unique=True, nullable=False)
    senha_hash = db.Column(db.String(256), nullable=False)
    telefone   = db.Column(db.String(20))
    is_admin   = db.Column(db.Boolean, default=False)
    ativo      = db.Column(db.Boolean, default=True)
    criado_em  = db.Column(db.DateTime, default=datetime.utcnow)

    # Relacionamento: um usuário pode ter várias reservas
    reservas   = db.relationship("Reserva", backref="usuario", lazy=True)

    def to_dict(self):
        return {
            "id": self.id, "nome": self.nome, "email": self.email,
            "telefone": self.telefone, "is_admin": self.is_admin,
            "ativo": self.ativo, "criado_em": self.criado_em.isoformat()
        }


class Quadra(db.Model):
    """Quadras esportivas disponíveis para agendamento."""
    __tablename__ = "quadras"

    id           = db.Column(db.Integer, primary_key=True)
    nome         = db.Column(db.String(100), nullable=False)
    tipo         = db.Column(db.String(50),  nullable=False)   # futebol, basquete, tênis...
    descricao    = db.Column(db.Text)
    preco_hora   = db.Column(db.Float, nullable=False)
    capacidade   = db.Column(db.Integer)
    foto_url     = db.Column(db.String(255))
    ativa        = db.Column(db.Boolean, default=True)
    criado_em    = db.Column(db.DateTime, default=datetime.utcnow)

    # Relacionamento: uma quadra pode ter várias reservas
    reservas     = db.relationship("Reserva", backref="quadra", lazy=True)

    def to_dict(self):
        return {
            "id": self.id, "nome": self.nome, "tipo": self.tipo,
            "descricao": self.descricao, "preco_hora": self.preco_hora,
            "capacidade": self.capacidade, "foto_url": self.foto_url,
            "ativa": self.ativa
        }


class Reserva(db.Model):
    """Reservas de quadras pelos usuários."""
    __tablename__ = "reservas"

    id          = db.Column(db.Integer, primary_key=True)
    usuario_id  = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    quadra_id   = db.Column(db.Integer, db.ForeignKey("quadras.id"),  nullable=False)
    data        = db.Column(db.Date,    nullable=False)
    hora_inicio = db.Column(db.Time,    nullable=False)
    hora_fim    = db.Column(db.Time,    nullable=False)
    status      = db.Column(db.String(20), default="confirmada")  # confirmada | cancelada
    valor_total = db.Column(db.Float)
    observacao  = db.Column(db.Text)
    criado_em   = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "usuario_id": self.usuario_id,
            "usuario_nome": self.usuario.nome if self.usuario else None,
            "quadra_id": self.quadra_id,
            "quadra_nome": self.quadra.nome if self.quadra else None,
            "data": self.data.isoformat(),
            "hora_inicio": self.hora_inicio.strftime("%H:%M"),
            "hora_fim": self.hora_fim.strftime("%H:%M"),
            "status": self.status,
            "valor_total": self.valor_total,
            "observacao": self.observacao,
            "criado_em": self.criado_em.isoformat()
        }


# ─────────────────────────────────────────────────────────────
#  INICIALIZAÇÃO COM DADOS PADRÃO
# ─────────────────────────────────────────────────────────────

def init_db():
    """Cria as tabelas e insere dados iniciais se o banco estiver vazio."""
    db.create_all()

    # Cria admin padrão se não existir
    if not Usuario.query.filter_by(email="admin@quadra.com").first():
        admin = Usuario(
            nome="Administrador",
            email="admin@quadra.com",
            senha_hash=generate_password_hash("admin123"),
            is_admin=True
        )
        db.session.add(admin)

    # Cria quadras de exemplo
    if Quadra.query.count() == 0:
        quadras_exemplo = [
            Quadra(nome="Quadra Society 1", tipo="Futebol Society",
                   descricao="Grama sintética de alta qualidade, iluminação LED",
                   preco_hora=120.0, capacidade=14, foto_url="⚽"),
            Quadra(nome="Quadra de Tênis", tipo="Tênis",
                   descricao="Piso em saibro, com placar eletrônico",
                   preco_hora=80.0, capacidade=4, foto_url="🎾"),
            Quadra(nome="Quadra de Basquete", tipo="Basquete",
                   descricao="Piso de madeira nobre, tabelas regulamentares",
                   preco_hora=100.0, capacidade=10, foto_url="🏀"),
            Quadra(nome="Quadra de Vôlei", tipo="Vôlei",
                   descricao="Areia especial importada, redes profissionais",
                   preco_hora=90.0, capacidade=12, foto_url="🏐"),
        ]
        db.session.add_all(quadras_exemplo)

    db.session.commit()
    print("✅ Banco de dados inicializado!")
