# 🏟️ QuadraApp – Sistema de Agendamento de Quadra Esportiva

## Estrutura do Projeto

```
quadra_esportiva/
│
├── app.py              ← Servidor Flask (ponto de entrada)
├── database.py         ← Modelos do banco (SQLAlchemy ORM)
├── requirements.txt    ← Dependências Python
│
├── routes/
│   ├── auth.py         ← Login / Cadastro / Logout
│   ├── quadras.py      ← Listagem e horários disponíveis
│   ├── reservas.py     ← Criar e cancelar reservas
│   └── admin.py        ← Painel admin (CRUD + Relatórios)
│
└── static/
    └── index.html      ← Frontend completo (HTML + CSS + JS)
```

---

## 🚀 Como Rodar

### 1. Instalar dependências
```bash
pip install -r requirements.txt
```

### 2. Iniciar o servidor
```bash
python app.py
```

### 3. Acessar no navegador
```
http://localhost:5000
```

### Credenciais padrão
| Campo | Valor         |
|-------|---------------|
| Email | admin@quadra.com |
| Senha | admin123      |

---

## 🔌 Migração para MySQL Workbench

### 1. Instalar o conector MySQL
```bash
pip install mysql-connector-python
```

### 2. Criar o banco no MySQL Workbench
```sql
CREATE DATABASE quadra_esportiva CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 3. Alterar a connection string em `app.py`
```python
# Linha atual (SQLite):
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///quadra.db"

# Substitua por (MySQL):
app.config["SQLALCHEMY_DATABASE_URI"] = (
    "mysql+mysqlconnector://SEU_USUARIO:SUA_SENHA@localhost/quadra_esportiva"
)
```

### 4. Reiniciar a aplicação
```bash
python app.py
```
As tabelas serão criadas automaticamente pelo SQLAlchemy.

---

## 📡 API REST (endpoints)

### Autenticação
| Método | Endpoint           | Descrição            |
|--------|--------------------|----------------------|
| POST   | /api/auth/cadastro | Criar conta          |
| POST   | /api/auth/login    | Login                |
| POST   | /api/auth/logout   | Logout               |
| GET    | /api/auth/me       | Usuário atual        |

### Quadras (público)
| Método | Endpoint                          | Descrição               |
|--------|-----------------------------------|-------------------------|
| GET    | /api/quadras/                     | Listar quadras ativas   |
| GET    | /api/quadras/{id}                 | Detalhes de uma quadra  |
| GET    | /api/quadras/{id}/horarios?data=  | Horários disponíveis    |

### Reservas (autenticado)
| Método | Endpoint                      | Descrição            |
|--------|-------------------------------|----------------------|
| POST   | /api/reservas/                | Criar reserva        |
| GET    | /api/reservas/minhas          | Minhas reservas      |
| PUT    | /api/reservas/{id}/cancelar   | Cancelar reserva     |

### Admin (somente administrador)
| Método | Endpoint                        | Descrição             |
|--------|---------------------------------|-----------------------|
| POST   | /api/admin/quadras              | Criar quadra          |
| PUT    | /api/admin/quadras/{id}         | Editar quadra         |
| DELETE | /api/admin/quadras/{id}         | Desativar quadra      |
| GET    | /api/admin/reservas             | Todas as reservas     |
| GET    | /api/admin/usuarios             | Todos os usuários     |
| PUT    | /api/admin/usuarios/{id}/toggle | Ativar/Desativar user |
| GET    | /api/admin/relatorio            | Estatísticas gerais   |
